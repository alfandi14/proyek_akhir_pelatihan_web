<?php $__env->startSection('content'); ?>
    <div class="card mt-5 mx-auto" style="width: 40rem">
        <div class="card-header">
            Halo, <?php echo e(Auth::user()->name); ?>

        </div>
        <div class="card-body">
            <table class="table">
                <thead class="thead-dark">
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Nama</th>
                        
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $penggunas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <th><?php echo e($loop->iteration); ?></th>
                            <td>
                                <?php echo e($item->nama); ?>

                            </td>
                            
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <th>Belum Ada Data</th>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <div class="card-footer">
            <a href="<?php echo e(route('pengguna.index')); ?>" class="btn btn-primary">Akses Pengguna</a>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ronald/Documents/crudsederhana/resources/views/welcome.blade.php ENDPATH**/ ?>