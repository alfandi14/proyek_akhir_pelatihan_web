<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header d-flex justify-content-between">
            <span>
                Pengguna
            </span>
            <div>
                <a href="<?php echo e(route('pengguna.create')); ?>" class="btn btn-primary">+</a>
            </div>
        </div>
        <div class="card-body">
            <table class="table">
                <div class="form-group">
                    <?php if($message = Session::get('success')): ?>
                        <div class="alert alert-success">
                            <?php echo e($message); ?>

                        </div>
                    <?php endif; ?>
                </div>
                <thead class="thead-dark">
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Nama</th>
                        <th scope="col">Umur</th>
                        <th scope="col">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $penggunas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <th><?php echo e($loop->iteration); ?></th>
                            <td>
                                <?php echo e($item->nama); ?>

                            </td>
                            <td>
                                <?php echo e($item->umur); ?>

                            </td>
                            <td class="d-flex">
                                <a href="<?php echo e(route('pengguna.edit', $item->id)); ?>" class="btn btn-success">Edit</a>
                                <a href="<?php echo e(route('pengguna.show', $item->id)); ?>" class="btn btn-warning mx-5">Show</a>
                                <form action="<?php echo e(route('pengguna.destroy', $item->id)); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('delete'); ?>
                                    <button class="btn btn-danger" onclick="return confirm('Yakin ingin menghapusnya ?')">Hapus</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ronald/Documents/crudsederhana/resources/views/pengguna/index.blade.php ENDPATH**/ ?>