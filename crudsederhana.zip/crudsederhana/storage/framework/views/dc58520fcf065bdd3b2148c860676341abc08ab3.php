<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Login</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
</head>
<body>


    <div class="container">
        <div class="card mx-auto mt-4" style="width: 30rem">
            <div class="card-header">
                Login
            </div>
            <div class="card-body">
                <form action="<?php echo e(route('masuk')); ?>" method="POST">
                    <?php if($message = Session::get('success')): ?>
                        <div class="alert alert-success">
                            <?php echo e($message); ?>

                        </div>
                    <?php endif; ?>
                    <?php if($message = Session::get('gagal')): ?>
                        <div class="alert alert-danger">
                            <?php echo e($message); ?>

                        </div>
                    <?php endif; ?>
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="">Email</label>
                        <input type="email" name="email" class="form-control">
                    </div>
                    <div class="form-group">
                        <label for="">Password</label>
                        <input type="password" name="password" class="form-control">
                    </div>
                    <div class="form-group">
                        <button class="btn btn-success btn-block">Login</button>
                    </div>
                </form>
            </div>
            <div class="card-footer">
                <span>
                    Belum Punya Akun ? <a href="<?php echo e(route('register')); ?>">Daftar</a>
                </span>
            </div>
        </div>
    </div>
    

    <script src="<?php echo e(asset('js/app.js')); ?>"></script>
</body>
</html><?php /**PATH C:\devweb\crudsederhana\resources\views/auth/login.blade.php ENDPATH**/ ?>