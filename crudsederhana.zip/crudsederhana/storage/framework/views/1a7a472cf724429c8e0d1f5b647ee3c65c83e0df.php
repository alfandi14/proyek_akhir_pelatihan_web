<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header d-flex justify-content-between align-items-center">
            <span>
                Detail Pengguna
            </span>
            <div>
                <a href="<?php echo e(route('pengguna.index')); ?>" class="btn btn-primary">Kembali</a>
            </div>
        </div>
        <div class="card-body">
            <div class="form-group">
                <label for="">Nama</label>
                <input type="text" readonly value="<?php echo e($pengguna->nama); ?>" class="form-control">
            </div>
            <div class="form-group">
                <label for="">Umur</label>
                <input type="text" readonly value="<?php echo e($pengguna->umur); ?>" class="form-control">
            </div>
            <div class="form-group">
                <label for="">Alamat</label>
                <input type="text" readonly value="<?php echo e($pengguna->alamat); ?>" class="form-control">
            </div>
            <div class="form-group">
                <label for="">Photo</label>
                <img src="<?php echo e(Storage::url($pengguna->photo)); ?>" alt="">
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ronald/Documents/crudsederhana/resources/views/pengguna/show.blade.php ENDPATH**/ ?>